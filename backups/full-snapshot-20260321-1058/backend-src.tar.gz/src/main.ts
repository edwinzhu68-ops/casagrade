import 'reflect-metadata';
try { require('dotenv/config'); } catch { /* 未安装 dotenv 时忽略，使用系统环境变量 */ }
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ExceptionFilter, Catch, ArgumentsHost, HttpStatus, HttpException, Logger } from '@nestjs/common';
import { Response } from 'express';
import * as fs from 'fs';
import * as path from 'path';

const logger = new Logger('Bootstrap');

// 写入错误日志到文件
function writeErrorLog(msg: string) {
  // __dirname 是 dist 目录，往上一级到 backend
  const logDir = path.join(__dirname, '..', 'logs');
  const logFile = path.join(logDir, `error-${new Date().toISOString().split('T')[0]}.log`);
  const logMsg = `[${new Date().toISOString()}] ${msg}\n`;
  
  try {
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }
    fs.appendFileSync(logFile, logMsg);
  } catch (e) {
    console.error('Failed to write error log:', e);
  }
  console.error(msg); // 同时输出到控制台，PM2 会捕获
}

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<Response>();
    
    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const body = exception.getResponse();
      return res.status(status).json(typeof body === 'object' ? body : { message: body });
    }
    
    // 生产环境也记录完整错误信息
    const isDev = process.env.NODE_ENV !== 'production';
    
    if (exception instanceof Error) {
      const errorMsg = isDev 
        ? `${exception.message}\n${exception.stack}`
        : `${exception.message}`;
      
      writeErrorLog(`[UnhandledException] ${errorMsg}`);
      
      res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
        message: isDev ? exception.message : 'Internal server error',
        error: 'Internal Server Error',
      });
    } else {
      writeErrorLog(`[UnhandledException] Unknown error: ${JSON.stringify(exception)}`);
      res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
        statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
        message: 'Internal server error',
        error: 'Internal Server Error',
      });
    }
  }
}

// 捕获未处理的进程错误
process.on('uncaughtException', (error) => {
  writeErrorLog(`[Process-uncaughtException] ${error.message}\n${error.stack}`);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  const msg = reason instanceof Error ? `${reason.message}\n${reason.stack}` : String(reason);
  writeErrorLog(`[Process-unhandledRejection] ${msg}`);
});

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log', 'debug', 'verbose'], // 开启所有日志级别
  });
  app.useGlobalFilters(new AllExceptionsFilter());

  const allowedOrigins = process.env.ALLOWED_ORIGINS;
  const isDev = process.env.NODE_ENV !== 'production';
  const defaultOrigins = isDev
    ? ['https://www.casagrade.com', 'https://casagrade.com', 'https://api.casagrade.com', 'http://localhost:3005', 'http://localhost:8080']
    : ['https://www.casagrade.com', 'https://casagrade.com', 'https://api.casagrade.com'];
  const origins = allowedOrigins
    ? allowedOrigins.split(',').map((s) => s.trim()).filter(Boolean)
    : defaultOrigins;
  app.enableCors({ origin: origins, credentials: true });
  app.setGlobalPrefix('api');

  const port = process.env.PORT || 3000;
  await app.listen(port);
  logger.log(`🚀 Lottery API running on http://localhost:${port}`);
}
bootstrap();
