// ============================================
// 巴拿马 Loteria 结算服务
// ============================================

import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Order, OrderPartial, Shop, Draw, MasterAgent } from './entities';
import { calculateBilletePayout, calculateChancePayout, DrawResult } from './loteria-rules';

@Injectable()
export class SettlementService {
  private readonly logger = new Logger(SettlementService.name);
  constructor(private readonly dataSource: DataSource) {}

  /**
   * 创建订单 - 支持全额/飞单
   */
  async createOrderWithPartial(
    storeCode: string, 
    numbers: string[], 
    betAmount: number,
    customerName?: string,
    customerPhone?: string
  ) {
    const shop = await this.dataSource.getRepository(Shop).findOne({
      where: { store_code: storeCode }
    });

    if (!shop || shop.status !== 'ACTIVE') {
      throw new Error('店铺不存在或已停业');
    }

    // 验证号码 (1-36)
    const validation = validateNumbers(numbers);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const verificationCode = this.generateCode();
    const orderRepo = this.dataSource.getRepository(Order);
    const order = orderRepo.create({
      store_code: storeCode,
      selection: { numbers },
      bet_amount: betAmount,
      verification_code: verificationCode,
      status: 'Pending',
      created_at: new Date(),
    });

    // 根据绑定类型处理
    if (shop.binding_type === 'FULL' && shop.master_id_full) {
      order.order_type = 'FULL';
      order.master_id_responsible = shop.master_id_full;
    } else if (shop.binding_type === 'PARTIAL' && shop.master_id_partial) {
      order.order_type = 'PARTIAL';
      order.master_id_responsible = shop.master_id_partial;
    } else {
      order.order_type = 'INDEPENDENT';
    }

    await orderRepo.save(order);
    return order;
  }

  /**
   * 结算 - Billete + Chance 规则
   */
  async settleDraw(drawId: number) {
    const draw = await this.dataSource.getRepository(Draw).findOne({
      where: { draw_id: drawId },
    });
    
    if (!draw || draw.status !== 'PUBLISHED') {
      throw new Error('开奖期次无效');
    }

    // 解析 Billete/Chance 开奖结果
    const winning: DrawResult = this.parseDrawResult(draw);

    const orders = await this.dataSource.getRepository(Order).find({
      where: { status: 'Paid', draw_id: drawId },
    });

    const results = {
      totalOrders: orders.length,
      totalSales: 0,
      totalPayout: 0,    // 总赔付
      masterProfit: 0,    // 庄家利润
      wins: 0,            // 中奖单数
    };

    for (const order of orders) {
      const selection = typeof order.selection === 'string'
        ? JSON.parse(order.selection)
        : order.selection;
      const numbers: string[] = (selection?.numbers || []) as string[];
      const multiplier = order.multiplier || 1;

      let orderSales = 0;
      let orderPayout = 0;

      for (const raw of numbers) {
        const s = String(raw);
        const isBillete = s.length >= 3; // 4位为主，兼容可能的 "0123"
        const perBet = order.bet_amount * multiplier;

        orderSales += perBet;

        if (isBillete) {
          const num = s.slice(-4);
          const result = calculateBilletePayout(num, winning, perBet);
          orderPayout += result.totalPayout;
        } else {
          const num = s.slice(-2);
          orderPayout += calculateChancePayout(num, winning, perBet);
        }
      }

      results.totalSales += orderSales;
      results.totalPayout += orderPayout;
      
      if (orderPayout > 0) {
        results.wins++;
      }

      if (order.order_type === 'FULL' && order.master_id_responsible) {
        // 全额：庄家承担全部风险
        results.masterProfit += orderSales - orderPayout;
        
      } else if (order.order_type === 'PARTIAL' && order.master_id_responsible) {
        // 飞单：分别计算
        const partials = await this.dataSource.getRepository(OrderPartial).find({
          where: { order_id: order.order_id }
        });
        
        for (const partial of partials) {
          const partialNumbers = partial.numbers.split(',');
          let partialSales = 0;
          let partialPayout = 0;

          for (const raw of partialNumbers) {
            const s = String(raw);
            const isBillete = s.length >= 3;
            const perBet = partial.bet_amount;

            partialSales += perBet;

            if (isBillete) {
              const num = s.slice(-4);
              const result = calculateBilletePayout(num, winning, perBet);
              partialPayout += result.totalPayout;
            } else {
              const num = s.slice(-2);
              partialPayout += calculateChancePayout(num, winning, perBet);
            }
          }

          const partialProfit = partialSales - partialPayout;
          results.masterProfit += partialProfit;

          await this.dataSource.getRepository(OrderPartial).update(partial.partial_id, {
            master_profit: partialProfit,
            settled_at: new Date(),
          });
        }
      }

      // 更新订单状态
      await this.dataSource.getRepository(Order).update(order.order_id, {
        status: orderPayout > 0 ? 'Won' : 'Lost',
        settled_at: new Date(),
      });
    }

    this.logger.log(`结算完成: ${results.totalOrders}单, 销售额$${results.totalSales}, 赔付$${results.totalPayout}, 中奖${results.wins}单, 庄家利润$${results.masterProfit}`);
    return results;
  }

  // 解析 Draw 中的 Billete/Chance 开奖结果，兼容多种存储格式
  private parseDrawResult(draw: Draw): DrawResult {
    const raw: any = (draw as any).winning_numbers;
    let obj: any = raw;

    if (typeof raw === 'string') {
      try {
        obj = JSON.parse(raw);
      } catch {
        // 非 JSON，则尝试用分隔符拆分为三个号码
        const parts = raw.split(/[-\s,]/).map((v: string) => v.trim()).filter((v: string) => v.length > 0);
        return {
          primer: (parts[0] || '0000').padStart(4, '0'),
          segundo: (parts[1] || '0000').padStart(4, '0'),
          tercero: (parts[2] || '0000').padStart(4, '0'),
        };
      }
    }

    // 兼容 dashboard/manualDraw 可能写入的字段名
    const primer = (obj.primer || obj.billete || obj.primeras || '').toString().padStart(4, '0');
    const segundo = (obj.segundo || obj.segundas || '').toString().padStart(4, '0');
    const tercero = (obj.tercero || obj.terceras || obj.ultimas || '').toString().padStart(4, '0');

    return { primer, segundo, tercero };
  }

  private generateCode(): string {
    return Math.floor(10000 + Math.random() * 90000).toString();
  }
}
