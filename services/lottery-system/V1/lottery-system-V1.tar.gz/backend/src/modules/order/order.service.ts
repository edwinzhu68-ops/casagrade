// ============================================
// 4. 订单创建 - 限额检查中间件
// ============================================

import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Order, Shop } from './entities';

interface CreateOrderDto {
  storeCode: string;
  numbers: string[];
  betAmount: number;
  multiplier?: number;
  customerName?: string;
  customerPhone?: string;
}

@Injectable()
export class OrderService {
  private readonly logger = new Logger(OrderService.name);

  constructor(private readonly dataSource: DataSource) {}

  /**
   * 创建订单 - 含限额检查
   */
  async createOrder(dto: CreateOrderDto): Promise<Order> {
    const { storeCode, numbers, betAmount, multiplier = 1, customerName, customerPhone } = dto;

    // 1. 检查店铺是否存在
    const shop = await this.dataSource.getRepository(Shop).findOne({
      where: { store_code: storeCode },
    });

    if (!shop) {
      throw new Error('店铺不存在');
    }

    if (shop.status !== 'ACTIVE') {
      throw new Error('店铺已停业');
    }

    // 2. 检查单笔限额
    if (betAmount > (shop.single_bet_limit || 100)) {
      throw new Error(`单笔最高投注 ${shop.single_bet_limit} 美元`);
    }

    // 3. 检查今日限额
    const today = new Date().toISOString().split('T')[0];
    const todayTotal = await this.getTodaySales(storeCode);
    
    if (todayTotal + betAmount > (shop.daily_bet_limit || 5000)) {
      throw new Error(`今日额度已满 (已投 ${todayTotal} / 限额 ${shop.daily_bet_limit})`);
    }

    // 4. 生成核销码
    const verificationCode = this.generateVerificationCode();

    // 5. 创建订单
    const orderRepo = this.dataSource.getRepository(Order);
    const order = orderRepo.create({
      store_code: storeCode,
      master_id: shop.master_id,
      selection: { numbers, type: 'direct' },
      bet_amount: betAmount,
      multiplier,
      customer_name: customerName,
      customer_phone: customerPhone,
      verification_code: verificationCode,
      status: 'Pending',
    });

    await orderRepo.save(order);

    this.logger.log(`订单创建: #${order.order_id}, 店号: ${storeCode}, 金额: $${betAmount}`);
    
    return order;
  }

  /**
   * 获取今日销售额
   */
  private async getTodaySales(storeCode: string): Promise<number> {
    const today = new Date().toISOString().split('T')[0];
    
    const result = await this.dataSource
      .getRepository(Order)
      .createQueryBuilder('order')
      .where('order.store_code = :storeCode', { storeCode })
      .andWhere('DATE(order.created_at) = :today', { today })
      // 只统计已付相关状态，不包含 Pending
      .andWhere('order.status IN (:...statuses)', { statuses: ['Paid', 'Won', 'Lost'] })
      .select('SUM(order.bet_amount * COALESCE(order.multiplier, 1))', 'total')
      .getRawOne();

    return Number(result?.total || 0);
  }

  /**
   * 生成5位不重复核销码
   */
  private generateVerificationCode(): string {
    // 简单实现：随机5位码
    return Math.floor(10000 + Math.random() * 90000).toString();
  }

  /**
   * 核销订单（老板确认收款）
   */
  async verifyOrder(verificationCode: string): Promise<Order> {
    const order = await this.dataSource.getRepository(Order).findOne({
      where: { verification_code: verificationCode },
    });

    if (!order) {
      throw new Error('核销码不存在');
    }

    // 超过30分钟未支付的订单自动取消
    const createdAt = order.created_at ? new Date(order.created_at) : null;
    if (createdAt) {
      const now = new Date();
      const diffMs = now.getTime() - createdAt.getTime();
      const THIRTY_MIN = 30 * 60 * 1000;
      if (diffMs > THIRTY_MIN) {
        await this.dataSource.getRepository(Order).update(order.order_id, {
          status: 'Canceled',
          canceled_at: new Date(),
        } as any);
        throw new Error('订单已超过30分钟未支付，已自动取消');
      }
    }

    if (order.status !== 'Pending') {
      throw new Error(`订单状态不是待支付: ${order.status}`);
    }

    // 更新为已支付
    await this.dataSource.getRepository(Order).update(order.order_id, {
      status: 'Paid',
      paid_at: new Date(),
    });

    order.status = 'Paid';
    order.paid_at = new Date();

    return order;
  }

  /**
   * 庄家看板统计SQL
   */
  async getMasterDashboard(masterId: number, period: 'today' | 'week' | 'month') {
    const dateField = period === 'today' ? 'CURDATE()' : 
                     period === 'week' ? 'DATE_SUB(CURDATE(), INTERVAL 7 DAY)' : 
                     'DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
    
    // 这个需要在 repository 中用原始 SQL 执行
    const sql = `
      SELECT 
        COUNT(*) as total_orders,
        SUM(bet_amount * COALESCE(multiplier, 1)) as total_bets,
        SUM(shop_commission) as total_commission,
        SUM(win_amount) as total_winnings,
        SUM(master_revenue) as net_revenue
      FROM orders
      WHERE master_id = ?
        AND created_at >= ${dateField}
        AND status IN ('Paid', 'Won', 'Lost')
    `;
    
    // 使用 queryRunner 执行原始 SQL
    const result = await this.dataSource.query(sql, [masterId]);
    return result[0];
  }
}
