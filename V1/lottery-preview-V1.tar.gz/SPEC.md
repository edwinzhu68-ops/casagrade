# 巴拿马彩票系统完整开发提示词

## 系统目标
- 支持 10000+ 店铺
- 单次开奖 50000+ 订单
- 高峰集中在开奖前3小时

---

## 一、账号系统

### 老板注册
- 随机5位数字账号（如48325）
- 字段：user_id, account_number, phone, password, created_at

### 店铺创建
- 随机5位店铺号（如73841）
- 字段：shop_id, shop_number, owner_id, shop_name, commission_rate, created_at

---

## 二、店铺绑定系统

- A店铺可申请绑定B店铺
- 绑定后佣金自动计算
- 字段：binding_id, shop_a, shop_b, commission_rate, status

---

## 三、客户端（顾客）

- 无需注册，输入店铺号进入
- 九宫格数字输入下单
- 订单状态：未付款 → 已付款 → 已开奖 → 已中奖

---

## 四、付款流程

1. 顾客下单 → 状态"未付款"
2. 顾客现金/WhatsApp转账
3. 老板端确认 → 状态"已付款"

---

## 五、订单系统

字段：
- order_id, shop_id, numbers, amount, status, draw_id, win_amount, created_at

状态：0未付款, 1已付款, 2已开奖, 3已中奖

订单号：时间戳+随机数

---

## 六、开奖系统

- 每周2次（周三、周日）
- Playwright爬虫自动获取
- 写入Redis缓存

---

## 七、中奖计算

- 批量处理（每批1000单）
- 避免数据库压力

---

## 八、数据保留规则

- 开奖后保留24小时
- 只保留统计数据到 shop_daily_stats

---

## 九、高并发架构

```
负载均衡 → API服务器×3 → Redis缓存 → PostgreSQL → RabbitMQ消息队列
```

---

## 十、防作弊机制

1. **开奖前5分钟停止下注**
2. **订单创建后不可修改**
3. **订单签名**：SHA256(order_id + numbers + amount + secret)
4. **管理员不可修改订单**
5. **防刷单**：同IP每秒最多5单
6. **二维码防伪**：order_id + order_hash

---

## 十一、通知系统

- WebSocket推送
- 新订单通知、绑定申请、开奖通知

---

## 开发优先级

1. 账号系统
2. 店铺系统
3. 客户端下注
4. 订单系统
5. 付款确认
6. 开奖爬虫
7. 中奖计算
8. 佣金系统
9. 防作弊
10. 高并发优化
